## BACALAH KETENTUAN DENGAN SEKSAMA - KAMI AKAN MENGANGGAP GUGUR JIKA PROSES TIDAK SESUAI
## LANGKAH PENGERJAAN TEST BATCH III DAN KETENTUAN

1. Clone project test dengan cara - git clone -b master --alamat url repository
2. sebelum mengerjakan test  buat branch baru dengan format nama/test-be-kawahedukasi contoh: 
        - git branch hambaly/test-be-kawahedukasi
        - git checkout hambaly/test-be-kawahedukasi
3. kemudian kerjakan projek yang berada di file test-introduction.txt, untuk bahasa pemrograman di sarankan hanya menggunakan php, java dan buatlah file dengan extention berikut
4. setelah selesai mengerjakan lalu push ke branch yang sudah tadi di buat dengan cara: 
    - git add .
    - git commit -m " Nama : Test Kawah Edukasi bath III "
    - git push origin nama/test-be-kawahedukasi

    note: untuk nama diisi sesuai nama pribadi dan branch yang sudah di buat dengan nama pribadi contoh : hambaly/test-be-kawahedukasi
5. Jika peserta terlihat kerjasama atau saling contek code program satu sama lain sama maka akan di pastikan gugur / tidak diterima
6. jika kode program sama maka akan di pastikan gugur
7. peserta wajib mengumpulkan soal test sebelum jam 3 sore
8. Jika peserta kesulitan ketika push atau terkait error & 403 file tersebut bisa di upload atau push ke github pribadi dan di set secara public, kemudian cantumkan link repositories pribadi yang sudah di jawab ke google form agar panitia bisa mengecek hasil jawaban


## SELAMAT MENGERJAKAN